package com.nomiresatras.desktop;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.nomiresatras.game.NoMiresAtrasGame;
public class DesktopLauncher {
  public static void main(String[] args) {
    Lwjgl3ApplicationConfiguration c = new Lwjgl3ApplicationConfiguration();
    c.setTitle("NO MIRES ATRÁS — Prototipo nativo"); c.setWindowedMode(1280,720); c.useVsync(true);
    new Lwjgl3Application(new NoMiresAtrasGame(), c);
  }
}
