# NO MIRES ATRÁS — Native Android 3D foundation

This is a new native Java/LibGDX project, not an HTML wrapper. It is a playable 3D vertical slice intended as the foundation for the larger game.

## Why this architecture
- Java + LibGDX, OpenGL ES on Android, Gradle project suitable for GitHub/Android Studio.
- A desktop launcher is included for faster iteration; Android is landscape-first.
- No React, Vite, browser DOM, or HTML game runtime.

## Build
Open the folder in Android Studio (JDK 17 recommended), allow Gradle sync, then run the `android` configuration on an Android device. The project uses LibGDX 1.13.1 and Android Gradle Plugin 8.7.3. Internet is required on first sync to download dependencies.

Desktop: run `com.nomiresatras.desktop.DesktopLauncher` from the desktop module after Gradle sync.

## Included in this first native slice
- Real-time 3D perspective scene, low-poly forest, trail, cabin shell, doorway, bedroom furniture.
- Android touch movement/look split; joystick forward uses camera-forward vector (not inverted).
- Desktop WASD/arrow fallback, run/stamina, flashlight point-light, camera-mode HUD.
- Tall creature silhouette with wide horizontal head, long arms, bright visible eyes, slow head/arm idle deformation.
- Crawler silhouette and simple approach behavior.
- Lightweight VHS scanlines, intermittent tracking bars, date/REC overlay; the image is not replaced by full-screen static.
- Basic forest/cabin collision boundaries and an open doorway route.

## Honest limitations
This is not yet a finished horror game or a polished asset pack. The creatures are procedural low-poly placeholders, not final rigged GLB models. The point light is an economical flashlight approximation; a true spot cone/shadow setup and volumetric beam still need a mobile performance pass. VHS noise is a lightweight overlay, not a full analog signal simulation. Audio, save/checkpoint system, full monster AI, full house interior, detailed map streaming, and professionally authored animations are not yet included. The first pass should be tested on the target Android phone before adding expensive shadows/post-processing.

## Source project fusion notes
The two supplied projects are TypeScript/Three.js browser games, not Java/Android projects. Their useful design logic was reviewed and translated rather than blindly merged:
- The larger project contributes its five-monster cast, VHS encounter logic, world/cabin progression and audio/gameplay organization.
- The controls-corrected project contributes the separated touch zones, flashlight beam intent, forest/corridor/cabin composition and creature archetypes.
- The earlier standalone HTML is not used as a base; only the requested corridor/flashlight design ideas were considered.

## Next production steps
1. Replace procedural placeholders with licensed, optimized GLB assets and authored skeleton animations.
2. Complete the forest map and a fully walkable house/bedroom with robust capsule collision.
3. Add monster state machines: distant observation, stalking, visible reveal, pursuit, search, retreat and unique behavior per creature.
4. Add spatialized footsteps, breathing, VHS motor noise, static bursts and creature-specific cues.
5. Add real spotlight/shadow support with quality tiers for Android GPUs, then profile on-device.
