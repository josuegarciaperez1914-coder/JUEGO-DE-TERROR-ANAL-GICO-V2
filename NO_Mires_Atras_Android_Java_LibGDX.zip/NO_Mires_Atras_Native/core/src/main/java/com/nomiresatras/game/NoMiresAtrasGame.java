package com.nomiresatras.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.PointLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.graphics.g3d.utils.ModelBatch;
import com.badlogic.gdx.graphics.g3d.utils.FirstPersonCameraController;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import java.util.Random;

/** Native 3D Android prototype. Procedural assets are intentionally lightweight. */
public class NoMiresAtrasGame extends ApplicationAdapter implements InputProcessor {
    private PerspectiveCamera camera;
    private ModelBatch modelBatch;
    private ModelBuilder builder;
    private Environment environment;
    private final Array<ModelInstance> world = new Array<>();
    private final Array<ModelInstance> trees = new Array<>();
    private final Array<ModelInstance> monsters = new Array<>();
    private ModelInstance alto, crawler;
    private ModelInstance altoHead, altoLeftArm, altoRightArm;
    private ModelInstance crawlerHead;
    private ModelInstance cabinDoor;
    private ModelInstance bed;
    private PointLight flashlight;
    private SpriteBatch hudBatch;
    private BitmapFont font;
    private ShapeRenderer shapes;
    private float yaw = 0f, pitch = 0f;
    private float joyX, joyY;
    private boolean running, touchRunning, flashlightOn = true, cameraMode = false;
    private boolean hasKey = false, doorOpen = false;
    private float elapsed, monsterDistance = 70f, staticPulse = 0f, glitchTimer = 1.5f;
    private float stamina = 100f;
    private float playerX = 0, playerZ = 7;
    private int lookPointer = -1, movePointer = -1;
    private float lastLookX, lastLookY, moveStartX=92, moveStartY=100;
    private final Vector3 tmp = new Vector3();
    private final Vector3 forward = new Vector3();
    private final Vector3 right = new Vector3();
    private final Random random = new Random(1993);
    private final float[][] treePositions = new float[90][2];

    @Override public void create() {
        modelBatch = new ModelBatch(); builder = new ModelBuilder();
        hudBatch = new SpriteBatch(); font = new BitmapFont(); shapes = new ShapeRenderer();
        camera = new PerspectiveCamera(72, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.position.set(0, 1.68f, playerZ); camera.direction.set(0,0,-1); camera.near=.08f; camera.far=115f; camera.update();
        environment = new Environment();
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, .095f,.105f,.105f,1));
        environment.add(new DirectionalLight().set(.23f,.25f,.22f,-.35f,-1f,-.2f));
        flashlight = new PointLight().set(0.0f,0.0f,0.0f, camera.position.x,camera.position.y,camera.position.z, 26f);
        environment.add(flashlight);
        buildWorld();
        Gdx.input.setCatchKey(Input.Keys.BACK, true);
        Gdx.input.setInputProcessor(this);
    }

    private Material mat(Color c, float rough) { return new Material(ColorAttribute.createDiffuse(c)); }
    private ModelInstance box(float w,float h,float d,Color color,float x,float y,float z) {
        Model m=builder.createBox(w,h,d, new Material(ColorAttribute.createDiffuse(color)), VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal);
        ModelInstance i=new ModelInstance(m); i.transform.setToTranslation(x,y,z); world.add(i); return i;
    }
    private ModelInstance sphere(float w,float h,float d,Color color,float x,float y,float z) {
        Model m=builder.createSphere(w,h,d,12,10,new Material(ColorAttribute.createDiffuse(color)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal);
        ModelInstance i=new ModelInstance(m); i.transform.setToTranslation(x,y,z); world.add(i); return i;
    }
    private void buildWorld() {
        box(180,.25f,180,new Color(.025f,.035f,.028f,1),0,-.22f,-25);
        // Narrow dirt trail through a dense but low-poly forest.
        box(5,.035f,100,new Color(.10f,.085f,.065f,1),0,-.06f,-25);
        for(int n=0;n<90;n++) {
            float z=-48+random.nextFloat()*93f;
            float side=random.nextBoolean()?1:-1;
            float x=side*(4.0f+random.nextFloat()*13f);
            treePositions[n][0]=x; treePositions[n][1]=z;
            float height=5.2f+random.nextFloat()*5.0f;
            ModelInstance trunk=box(.38f,height,.38f,new Color(.105f,.09f,.075f,1),x,height/2-.1f,z); trees.add(trunk);
            sphere(3.0f+random.nextFloat()*1.5f,3.8f+random.nextFloat()*2.4f,3.0f,new Color(.025f,.065f,.045f,1),x,height*.78f,z);
            if(n%3==0) sphere(1.6f,1.8f,1.7f,new Color(.035f,.075f,.045f,1),x+(random.nextFloat()-.5f)*2,.75f,z+1.5f);
        }
        // Small cabin with a deliberately clear entrance and a bedroom beyond it.
        float cz=-34f;
        box(8,.25f,9,new Color(.16f,.14f,.12f,1),0,.05f,cz);
        box(.22f,3.2f,9,new Color(.10f,.095f,.085f,1),-4,1.65f,cz);
        box(.22f,3.2f,9,new Color(.10f,.095f,.085f,1),4,1.65f,cz);
        box(8,3.2f,.22f,new Color(.09f,.085f,.075f,1),0,1.65f,cz-4.5f);
        // Front wall split around 1.5m doorway.
        box(3.2f,3.2f,.22f,new Color(.10f,.095f,.085f,1),-2.4f,1.65f,cz+4.5f);
        box(3.2f,3.2f,.22f,new Color(.10f,.095f,.085f,1),2.4f,1.65f,cz+4.5f);
        box(1.6f,.45f,.24f,new Color(.10f,.095f,.085f,1),0,2.98f,cz+4.5f);
        cabinDoor=box(1.45f,2.55f,.12f,new Color(.16f,.075f,.045f,1),0,1.3f,cz+4.42f);
        // Bedroom furniture: bed and wardrobe are visible inside, not blocking doorway.
        bed=box(2.3f,.45f,2.7f,new Color(.20f,.19f,.17f,1),1.55f,.43f,cz-1.4f);
        box(2.4f,.18f,2.8f,new Color(.32f,.30f,.27f,1),1.55f,.72f,cz-1.4f);
        box(1.7f,2.5f,.8f,new Color(.075f,.065f,.055f,1),-2.8f,1.25f,cz-3.25f);
        // Rusted lamp / red warning point.
        sphere(.16f,.16f,.16f,new Color(.65f,.035f,.02f,1),-2.6f,2.7f,cz-3.4f);
        buildAlto(); buildCrawler();
    }

    private ModelInstance makeLimb(float radius,float length,Color c,float x,float y,float z) {
        Model m=builder.createCylinder(radius*2,length,radius*2,8,new Material(ColorAttribute.createDiffuse(c)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal);
        ModelInstance i=new ModelInstance(m); i.transform.setToTranslation(x,y,z); world.add(i); return i;
    }
    private void buildAlto() {
        Color black=new Color(.008f,.009f,.012f,1), eye=new Color(.95f,.93f,.82f,1);
        alto=new ModelInstance(builder.createSphere(1.55f,4.3f,1.05f,14,12,new Material(ColorAttribute.createDiffuse(black)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal));
        alto.transform.setToTranslation(-8,2.15f,-22); monsters.add(alto);
        altoHead=new ModelInstance(builder.createBox(4.8f,.48f,1.05f,new Material(ColorAttribute.createDiffuse(black)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal));
        altoHead.transform.setToTranslation(-8,4.55f,-22); monsters.add(altoHead);
        // Eyes are deliberately visible at distance without becoming two tiny floating pixels.
        Model eyeModel=builder.createSphere(.24f,.18f,.12f,10,8,new Material(ColorAttribute.createDiffuse(eye)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal);
        ModelInstance e1=new ModelInstance(eyeModel); e1.transform.setToTranslation(-8.48f,4.57f,-21.43f); world.add(e1);
        ModelInstance e2=new ModelInstance(eyeModel); e2.transform.setToTranslation(-7.52f,4.57f,-21.43f); world.add(e2);
        altoLeftArm=makeLimb(.23f,3.8f,black,-8.95f,1.8f,-22);
        altoRightArm=makeLimb(.23f,3.8f,black,-7.05f,1.8f,-22);
        makeLimb(.22f,3.2f,black,-8.35f,-.1f,-22); makeLimb(.22f,3.2f,black,-7.65f,-.1f,-22);
    }
    private void buildCrawler() {
        Color flesh=new Color(.19f,.20f,.17f,1), pale=new Color(.39f,.40f,.34f,1), eye=new Color(.88f,.82f,.65f,1);
        crawler=new ModelInstance(builder.createSphere(1.45f,.8f,2.0f,12,10,new Material(ColorAttribute.createDiffuse(flesh)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal));
        crawler.transform.setToTranslation(9,.72f,-39); monsters.add(crawler);
        crawlerHead=new ModelInstance(builder.createSphere(.72f,.9f,.7f,12,10,new Material(ColorAttribute.createDiffuse(pale)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal));
        crawlerHead.transform.setToTranslation(9,1.0f,-40.2f); monsters.add(crawlerHead);
        Model em=builder.createSphere(.12f,.12f,.12f,8,8,new Material(ColorAttribute.createDiffuse(eye)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal);
        ModelInstance a=new ModelInstance(em); a.transform.setToTranslation(8.72f,1.15f,-39.85f); world.add(a);
        ModelInstance b=new ModelInstance(em); b.transform.setToTranslation(9.28f,1.15f,-39.85f); world.add(b);
        for(int s=-1;s<=1;s+=2) for(int k=0;k<2;k++) makeLimb(.14f,2.2f,flesh,9+s*(.8f+k*.2f),.45f,-39.3f-k*.9f);
    }

    @Override public void render() {
        float dt=Math.min(Gdx.graphics.getDeltaTime(),.04f); elapsed+=dt;
        updateInput(dt); updateWorld(dt);
        ScreenUtils.clear(.008f,.012f,.012f,1,true);
        camera.position.set(playerX,1.68f,playerZ);
        forward.set(MathUtils.sin(yaw),0,-MathUtils.cos(yaw)).nor();
        camera.direction.set(forward.x,MathUtils.sin(pitch),forward.z).nor(); camera.up.set(Vector3.Y); camera.update();
        flashlight.set(flashlightOn?1.55f:0f, flashlightOn?1.48f:0f, flashlightOn?1.25f:0f, camera.position, flashlightOn?30f:0f);
        modelBatch.begin(camera); for(ModelInstance i:world) modelBatch.render(i,environment); for(ModelInstance i:monsters) modelBatch.render(i,environment); modelBatch.end();
        drawHud();
    }

    private void updateInput(float dt) {
        if(Gdx.input.isKeyPressed(Input.Keys.A)) joyX=-1; else if(Gdx.input.isKeyPressed(Input.Keys.D)) joyX=1;
        if(Gdx.input.isKeyPressed(Input.Keys.W)) joyY=1; else if(Gdx.input.isKeyPressed(Input.Keys.S)) joyY=-1;
        running=touchRunning || Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT);
        if(Gdx.input.isKeyJustPressed(Input.Keys.F)) flashlightOn=!flashlightOn;
        if(Gdx.input.isKeyJustPressed(Input.Keys.C)) cameraMode=!cameraMode;
        float speed=running&&stamina>1?5.1f:2.65f;
        if(running&&Math.abs(joyY)+Math.abs(joyX)>.1f) stamina=Math.max(0,stamina-19*dt); else stamina=Math.min(100,stamina+11*dt);
        forward.set(MathUtils.sin(yaw),0,-MathUtils.cos(yaw)).nor(); right.set(forward).crs(Vector3.Y).nor();
        Vector3 move=new Vector3(forward).scl(joyY).mulAdd(right,joyX); if(move.len2()>1)move.nor();
        float nx=playerX+move.x*speed*dt, nz=playerZ+move.z*speed*dt;
        // Soft collision: forest trunks + cabin walls; doorway remains open and passable.
        boolean blocked=false;
        for(float[] p:treePositions) if(Vector3.dst2(nx,0,nz,p[0],0,p[1])<.78f*.78f){blocked=true;break;}
        if(nz<-29.45f&&nz>-38.7f && Math.abs(nx)>3.45f) blocked=true;
        if(nz<-38.35f) blocked=true;
        if(nz<-29.45f&&nz>-38.7f&&Math.abs(nx)<.82f&&nz<-29.5f) { /* doorway */ }
        if(!blocked){playerX=MathUtils.clamp(nx,-17,17);playerZ=MathUtils.clamp(nz,-54,12);}
        // Desktop keyboard fallback.
        if(Gdx.input.isKeyPressed(Input.Keys.LEFT)) yaw+=1.6f*dt;
        if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)) yaw-=1.6f*dt;
    }

    private void updateWorld(float dt) {
        // The Tall has its own unsettling idle: slow head dips, shoulder sway and long-arm lag.
        float breathe=(float)Math.sin(elapsed*1.35f);
        altoHead.transform.setToTranslation(-8,4.55f+(float)Math.sin(elapsed*.75f)*.10f,-22);
        altoHead.transform.rotate(Vector3.X, 8f+(float)Math.sin(elapsed*.48f)*13f);
        altoLeftArm.transform.setToTranslation(-8.95f,1.8f+breathe*.16f,-22);
        altoRightArm.transform.setToTranslation(-7.05f,1.8f-breathe*.13f,-22);
        // Occasionally leans down toward the player if in view range.
        monsterDistance=Vector3.dst(playerX,0,playerZ,-8,0,-22);
        if(monsterDistance<24) { staticPulse=Math.max(staticPulse,.28f+(.42f/(monsterDistance+1))); }
        crawlerHead.transform.setToTranslation(9+MathUtils.sin(elapsed*1.7f)*.16f,1.0f+Math.abs(MathUtils.sin(elapsed*2.3f))*.18f,-40.2f);
        // Crawler slowly approaches if player reaches the clearing; never teleports into the camera.
        if(playerZ<-18) {
            Vector3 target=new Vector3(playerX,.7f,playerZ-2.5f);
            Vector3 pos=new Vector3(9,.72f,-39); Vector3 d=target.sub(pos); d.y=0;
            if(d.len()>2.4f) { d.nor().scl(dt*.65f); crawler.transform.translate(d); crawlerHead.transform.translate(d); }
        }
        staticPulse=Math.max(0,staticPulse-dt*.24f);
        glitchTimer-=dt; if(glitchTimer<=0){ if(monsterDistance<25)staticPulse=Math.max(staticPulse,.5f); glitchTimer=2.0f+random.nextFloat()*5f; }
        // Door interaction is intentionally simple for this first native slice.
        if(Gdx.input.isKeyJustPressed(Input.Keys.E)&&playerZ<-26&&playerZ>-31&&Math.abs(playerX)<2.2f){doorOpen=!doorOpen; if(doorOpen)cabinDoor.transform.rotate(Vector3.Y,82f);}
    }

    private void drawHud() {
        float w=Gdx.graphics.getWidth(), h=Gdx.graphics.getHeight();
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        // Subtle VHS scanlines and occasional tracking tear; gameplay image remains readable.
        shapes.setColor(0,0,0,.13f);
        for(int y=0;y<h;y+=4) shapes.rect(0,y,w,1);
        if(staticPulse>.03f){
            for(int i=0;i<22;i++){float yy=random.nextFloat()*h; shapes.setColor(.72f,.78f,.72f,Math.min(.24f,staticPulse*.28f)); shapes.rect(random.nextFloat()*w,yy,random.nextFloat()*w*.45f+8,1+random.nextFloat()*3);}
        }
        if(glitchTimer<.05f&&monsterDistance<28){shapes.setColor(.7f,.8f,.72f,.16f);shapes.rect(0,h*.68f,w,3);}
        // Touch controls: left virtual stick, right-side action buttons.
        shapes.setColor(.8f,.85f,.8f,.13f); shapes.circle(92,100,58,32); shapes.setColor(.8f,.85f,.8f,.24f); shapes.circle(92+joyX*22,100+joyY*22,22,24);
        button(w-190,86,82,42,flashlightOn?"LINTERNA":"LUZ OFF"); button(w-98,86,82,42,"CÁMARA"); button(w-190,36,82,38,"CORRER"); button(w-98,36,82,38,"USAR");
        shapes.end();
        hudBatch.begin();
        font.setColor(.78f,.82f,.75f,1); font.getData().setScale(1.05f); font.draw(hudBatch,"REC   31 OCT 1993   00:"+String.format("%02d",((int)elapsed)%60),18,h-20);
        font.setColor(.72f,.74f,.68f,1); font.getData().setScale(.9f); font.draw(hudBatch,"BATERÍA  " +(int)stamina+"%",18,h-46);
        font.draw(hudBatch,cameraMode?"CAM: VHS":"CAM: OFF",18,h-68);
        font.setColor(.9f,.9f,.84f,1); font.getData().setScale(.82f);
        font.draw(hudBatch,flashlightOn?"LUZ":"LUZ OFF",Gdx.graphics.getWidth()-181,112);
        font.draw(hudBatch,"VHS",Gdx.graphics.getWidth()-76,112);
        font.draw(hudBatch,"CORRER",Gdx.graphics.getWidth()-177,60);
        font.draw(hudBatch,"USAR",Gdx.graphics.getWidth()-77,60);
        if(playerZ<-25&&playerZ>-32) font.draw(hudBatch,"TOCA USAR / E PARA ABRIR",w*.5f-90,h*.72f);
        hudBatch.end();
    }
    private void button(float x,float y,float w,float h,String label){shapes.setColor(.8f,.85f,.8f,.12f);shapes.rect(x,y,w,h);}

    @Override public boolean touchDown(int screenX,int screenY,int pointer,int button) {
        float x=screenX, y=Gdx.graphics.getHeight()-screenY, w=Gdx.graphics.getWidth();
        if(x<w*.45f){movePointer=pointer; moveStartX=x; moveStartY=y; joyX=0;joyY=0;return true;}
        if(y<140&&x>w-205&&x<w-105){if(y<78)touchRunning=true;else flashlightOn=!flashlightOn;return true;}
        if(y<140&&x>w-105){if(y<78){doorOpen=!doorOpen;}else cameraMode=!cameraMode;return true;}
        lookPointer=pointer;lastLookX=x;lastLookY=y;return true;
    }
    @Override public boolean touchDragged(int x,int y,int pointer){float sx=x,sy=Gdx.graphics.getHeight()-y;
        if(pointer==movePointer){float dx=(sx-moveStartX)/58f,dy=(sy-moveStartY)/58f;joyX=MathUtils.clamp(dx,-1,1);joyY=MathUtils.clamp(dy,-1,1);}
        else if(pointer==lookPointer){yaw-=(sx-lastLookX)*.006f;pitch=MathUtils.clamp(pitch+(sy-lastLookY)*.004f,-.65f,.65f);lastLookX=sx;lastLookY=sy;}return true;}
    @Override public boolean touchUp(int x,int y,int pointer,int button){if(pointer==movePointer){movePointer=-1;joyX=joyY=0;}if(pointer==lookPointer)lookPointer=-1;touchRunning=false;running=false;return true;}
    @Override public boolean touchCancelled(int x,int y,int pointer,int button){return touchUp(x,y,pointer,button);}
    @Override public boolean keyDown(int keycode){return false;}
    @Override public boolean keyUp(int keycode){return false;}
    @Override public boolean keyTyped(char character){return false;}
    @Override public boolean mouseMoved(int screenX,int screenY){return false;}
    @Override public boolean scrolled(float amountX,float amountY){return false;}
    @Override public void resize(int width,int height){camera.viewportWidth=width;camera.viewportHeight=height;camera.update();}
    @Override public void dispose(){modelBatch.dispose();hudBatch.dispose();font.dispose();shapes.dispose();for(ModelInstance i:world)i.model.dispose();for(ModelInstance i:monsters)i.model.dispose();}
}
