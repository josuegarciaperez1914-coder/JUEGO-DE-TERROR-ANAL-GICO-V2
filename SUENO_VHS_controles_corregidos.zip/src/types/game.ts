export type GamePhase =
  | 'menu'
  | 'playing'
  | 'paused'
  | 'options'
  | 'credits'
  | 'good-ending'
  | 'bad-ending'
  | 'caught';

export type Quality = 'low' | 'medium' | 'high';

export interface Settings {
  quality: Quality;
  volume: number; // 0..1
  sensitivity: number; // 0.3..2
  vhsIntensity: number; // 0.3..1.5
  callsign: string;
}

export type MonsterKind = 'alto' | 'rastrero' | 'deforme' | 'cazador' | 'armario';

export interface ObjectiveState {
  radio1: boolean;
  radio2: boolean;
  radio3: boolean;
  casa: boolean; // reached bedroom area
  dormir: boolean;
}

export interface HudSnapshot {
  timestamp: string;
  battery: number; // 0..100 camcorder
  flashlightOn: boolean;
  camOn: boolean;
  chaseActive: boolean;
  score: number;
  prompt: string | null;
  subtitle: string | null;
  radios: [boolean, boolean, boolean];
  casaReached: boolean;
  dangerFlash: boolean; // short red flash on hits / sightings
  interference: number; // 0..1 extra VHS distortion
  message: string | null; // feed like "+500 · RADIO ENCONTRADA"
}

export interface HighScoreEntry {
  id: string;
  name: string;
  score: number;
  radios: number;
  ending: 'BUENO' | 'MALO' | 'CAPTURADO' | 'ABANDONO';
  timeSec: number;
  date: string;
}

export interface SavedRun {
  version: number;
  radios: [boolean, boolean, boolean];
  score: number;
  callsign: string;
}

export interface EndingSummary {
  mode: 'good' | 'bad' | 'caught';
  score: number;
  timeSec: number;
  radios: number;
}
