// Motor de audio procedural — SUEÑO VHS
// Viento, pasos, estática, risas macabras, rugidos, crepitar de armario y voz de la madre.

type LaughKind = 'alto' | 'rastrero' | 'deforme' | 'cazador' | 'armario';

class VhsAudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambient: GainNode | null = null;
  private windNode: AudioBufferSourceNode | null = null;
  private heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  private whisperTimer: ReturnType<typeof setTimeout> | null = null;
  private volume = 0.8;
  private running = false;

  unlock(): void {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.volume * 0.9;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
  }

  setVolume(v: number): void {
    this.volume = v;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(v * 0.9, this.ctx.currentTime, 0.05);
  }

  startAmbient(): void {
    this.unlock();
    if (!this.ctx || !this.master || this.running) return;
    const ctx = this.ctx;
    this.ambient = ctx.createGain();
    this.ambient.gain.value = 0.35;
    this.ambient.connect(this.master);

    // Viento: ruido rosa-ish filtrado con LFO
    const len = ctx.sampleRate * 3;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      last = (last + 0.02 * white) / 1.02;
      d[i] = last * 3.2;
    }
    this.windNode = ctx.createBufferSource();
    this.windNode.buffer = buf;
    this.windNode.loop = true;
    const wf = ctx.createBiquadFilter();
    wf.type = 'lowpass';
    wf.frequency.value = 420;
    const wg = ctx.createGain();
    wg.gain.value = 0.5;
    this.windNode.connect(wf); wf.connect(wg); wg.connect(this.ambient);
    this.windNode.start();

    // LFO del viento
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.07;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 240;
    lfo.connect(lfoGain); lfoGain.connect(wf.frequency);
    lfo.start();

    // susurros lejanos aleatorios
    const whisper = () => {
      if (!this.running) return;
      if (Math.random() < 0.55) this.playWhisper();
      this.whisperTimer = setTimeout(whisper, 9000 + Math.random() * 14000);
    };
    this.whisperTimer = setTimeout(whisper, 6000);

    this.running = true;
  }

  stopAmbient(): void {
    this.running = false;
    try { this.windNode?.stop(); } catch { /* ignore */ }
    this.windNode = null;
    if (this.whisperTimer) clearTimeout(this.whisperTimer);
    this.stopHeartbeat();
    this.ambient?.disconnect();
    this.ambient = null;
  }

  private noiseBurst(dur: number, freq: number, q: number, gain: number, type: BiquadFilterType = 'bandpass', delay = 0): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const t = ctx.currentTime + delay;
    const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < len; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start(t);
  }

  footstep(run: boolean, indoor: boolean): void {
    if (!this.ctx) return;
    this.noiseBurst(0.07, indoor ? 240 : 480, 1.2, run ? 0.22 : 0.13, 'bandpass');
    if (!indoor) this.noiseBurst(0.16, 2200, 0.6, run ? 0.08 : 0.045, 'highpass', 0.015); // hojas
  }

  monsterStep(gain: number): void {
    this.noiseBurst(0.1, 130, 1.5, gain, 'lowpass');
  }

  flashlightClick(on: boolean): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = 'square';
    o.frequency.setValueAtTime(on ? 900 : 620, t);
    o.frequency.exponentialRampToValueAtTime(on ? 500 : 320, t + 0.03);
    g.gain.setValueAtTime(0.12, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
    o.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + 0.05);
    if (on) this.noiseBurst(0.03, 5200, 2, 0.05, 'highpass', 0.02);
  }

  camToggle(on: boolean): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx, t = ctx.currentTime;
    [0, 0.06].forEach((dl, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = (on ? 1300 : 1000) - i * 180;
      g.gain.setValueAtTime(0.07, t + dl);
      g.gain.exponentialRampToValueAtTime(0.001, t + dl + 0.045);
      o.connect(g); g.connect(this.master!);
      o.start(t + dl); o.stop(t + dl + 0.05);
    });
  }

  radioStatic(dur = 1.2): void {
    this.noiseBurst(dur, 1600, 0.5, 0.2);
    if (this.ctx && this.master) {
      const t = this.ctx.currentTime;
      const o = this.ctx.createOscillator();
      o.type = 'square'; o.frequency.value = 88;
      const f = this.ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 600;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.06, t);
      g.gain.setValueAtTime(0.06, t + dur * 0.8);
      g.gain.linearRampToValueAtTime(0.001, t + dur);
      o.connect(f); f.connect(g); g.connect(this.master);
      o.start(t); o.stop(t + dur);
    }
  }

  pickup(): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx, t = ctx.currentTime;
    [520, 780].forEach((fr, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'triangle'; o.frequency.value = fr;
      g.gain.setValueAtTime(0.12, t + i * 0.07);
      g.gain.exponentialRampToValueAtTime(0.001, t + i * 0.07 + 0.12);
      o.connect(g); g.connect(this.master!);
      o.start(t + i * 0.07); o.stop(t + i * 0.07 + 0.13);
    });
  }

  private distortCurve(amount: number): Float32Array<ArrayBuffer> {
    const n = 128;
    const curve = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = (i * 2) / n - 1;
      curve[i] = Math.tanh(x * amount);
    }
    return curve;
  }

  // Risa macabra granulada: sílabas descendentes distorsionadas
  laugh(kind: LaughKind, gainMul = 1): void {
    this.unlock();
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx;
    const base = kind === 'alto' ? 210 : kind === 'rastrero' ? 130 : kind === 'deforme' ? 300 : kind === 'cazador' ? 75 : 160;
    const syllables = kind === 'rastrero' ? 7 : kind === 'deforme' ? 5 : 6;
    const gap = kind === 'rastrero' ? 0.09 : 0.14;

    const shaper = ctx.createWaveShaper();
    shaper.curve = this.distortCurve(4.5);
    const sharedF = ctx.createBiquadFilter();
    sharedF.type = 'bandpass';
    sharedF.frequency.value = 900;
    sharedF.Q.value = 1.4;
    const out = ctx.createGain();
    // eco sobrenatural
    const delay = ctx.createDelay(0.6);
    delay.delayTime.value = 0.22;
    const fb = ctx.createGain(); fb.gain.value = 0.35;
    out.connect(this.master);
    out.connect(delay); delay.connect(fb); fb.connect(delay); delay.connect(this.master);

    const startG = (kind === 'armario' ? 0.5 : 0.4) * gainMul;
    for (let i = 0; i < syllables; i++) {
      const t = ctx.currentTime + i * gap + (kind === 'rastrero' ? (i % 2) * 0.02 : 0);
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      const drop = 1 - i * (kind === 'deforme' ? 0.10 : 0.06);
      const f0 = base * drop * (1 + Math.random() * 0.05);
      osc.frequency.setValueAtTime(f0, t);
      osc.frequency.exponentialRampToValueAtTime(f0 * 0.72, t + gap * 0.8);
      const vib = ctx.createOscillator();
      vib.frequency.value = kind === 'deforme' ? 11 : 7;
      const vibG = ctx.createGain(); vibG.gain.value = f0 * 0.12;
      vib.connect(vibG); vibG.connect(osc.frequency);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(startG, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, t + gap * 0.85);
      osc.connect(sharedF); sharedF.connect(shaper); shaper.connect(g); g.connect(out);
      osc.start(t); osc.stop(t + gap);
      vib.start(t); vib.stop(t + gap);
    }
    this.noiseBurst(0.4, 3000, 0.4, 0.12 * gainMul, 'highpass');
  }

  growl(): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(66, t);
    o.frequency.exponentialRampToValueAtTime(38, t + 1.3);
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 300;
    const shaper = ctx.createWaveShaper(); shaper.curve = this.distortCurve(6);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.5, t + 0.12);
    g.gain.exponentialRampToValueAtTime(0.001, t + 1.4);
    o.connect(f); f.connect(shaper); shaper.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + 1.5);
    this.noiseBurst(1.1, 190, 0.8, 0.22, 'lowpass');
  }

  catchScream(): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx, t = ctx.currentTime;
    [196, 247, 311].forEach((fr) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(fr * 2, t);
      o.frequency.linearRampToValueAtTime(fr * 0.8, t + 0.9);
      g.gain.setValueAtTime(0.2, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 1.0);
      o.connect(g); g.connect(this.master!);
      o.start(t); o.stop(t + 1.1);
    });
    this.noiseBurst(1.0, 2400, 0.4, 0.4, 'highpass');
  }

  creak(): void {
    if (!this.ctx || !this.master) return;
    const ctx = this.ctx, t = ctx.currentTime;
    const o = ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(160, t);
    o.frequency.linearRampToValueAtTime(70, t + 1.6);
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 340; f.Q.value = 9;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    const steps = 8;
    for (let i = 0; i < steps; i++) {
      g.gain.linearRampToValueAtTime(0.14 - i * 0.012, t + (i + 0.5) * 0.2);
      g.gain.linearRampToValueAtTime(0.03, t + (i + 1) * 0.2);
    }
    g.gain.linearRampToValueAtTime(0.001, t + steps * 0.2 + 0.2);
    o.connect(f); f.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + steps * 0.2 + 0.3);
    this.noiseBurst(0.5, 120, 1.5, 0.1, 'lowpass', 0.1);
  }

  glitchBurst(intensity = 0.3): void {
    this.noiseBurst(0.5, 5000, 0.3, intensity, 'highpass');
    this.noiseBurst(0.4, 90, 1, intensity * 0.8, 'lowpass');
  }

  playWhisper(): void {
    this.noiseBurst(1.4, 900, 6, 0.05);
    this.noiseBurst(1.0, 1600, 9, 0.035);
  }

  startHeartbeat(): void {
    if (this.heartbeatTimer || !this.ctx || !this.master) return;
    const beat = () => {
      if (!this.ctx || !this.master) return;
      const t = this.ctx.currentTime;
      [0, 0.16].forEach((dl, i) => {
        const o = this.ctx!.createOscillator();
        const g = this.ctx!.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(i === 0 ? 68 : 58, t + dl);
        o.frequency.exponentialRampToValueAtTime(40, t + dl + 0.12);
        g.gain.setValueAtTime(0.3 - i * 0.1, t + dl);
        g.gain.exponentialRampToValueAtTime(0.001, t + dl + 0.14);
        o.connect(g); g.connect(this.master!);
        o.start(t + dl); o.stop(t + dl + 0.15);
      });
    };
    beat();
    this.heartbeatTimer = setInterval(beat, 1050);
  }

  stopHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = null;
  }

  // Voz de la madre — síntesis de voz en español (si el navegador la soporta)
  speak(text: string, opts?: { pitch?: number; rate?: number; whispery?: boolean }): Promise<void> {
    return new Promise((resolve) => {
      try {
        if (!('speechSynthesis' in window)) { resolve(); return; }
        window.speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.lang = 'es-ES';
        u.pitch = opts?.pitch ?? 0.75;
        u.rate = opts?.rate ?? 0.72;
        u.volume = 0.85;
        const voices = window.speechSynthesis.getVoices();
        const es = voices.find((v) => v.lang.toLowerCase().startsWith('es'));
        if (es) u.voice = es;
        u.onend = () => resolve();
        u.onerror = () => resolve();
        this.radioStatic(Math.max(1.2, text.length * 0.06));
        window.speechSynthesis.speak(u);
        // fallback por si no dispara onend
        setTimeout(resolve, text.length * 110 + 2500);
      } catch {
        resolve();
      }
    });
  }
}

export const vhsAudio = new VhsAudioEngine();
