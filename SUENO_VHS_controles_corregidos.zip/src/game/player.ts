import * as THREE from 'three';
import { BoxCol, CircleCol, collideMove } from './world';

// Controlador de jugador en primera persona con soporte de teclado, ratón (pointer lock) y táctil.
export class PlayerController {
  public camera: THREE.PerspectiveCamera;
  public yaw = 0;
  public pitch = 0;
  public pos = new THREE.Vector3(0, 1.62, 46);
  public vel = new THREE.Vector3();
  public running = false;
  public speed = 0;
  public bobPhase = 0;
  public onStep: ((run: boolean, indoor: boolean) => void) | null = null;
  public locked = false; // true durante cinemáticas finales

  private keys = new Set<string>();
  private moveVec = new THREE.Vector2(0, 0); // táctil
  private runTouch = false;
  private sensitivity = 1;
  private indoorFn: (p: THREE.Vector3) => boolean;
  private circles: CircleCol[];
  private boxes: BoxCol[];

  constructor(camera: THREE.PerspectiveCamera, circles: CircleCol[], boxes: BoxCol[], indoorFn: (p: THREE.Vector3) => boolean) {
    this.camera = camera;
    this.circles = circles;
    this.boxes = boxes;
    this.indoorFn = indoorFn;
    this.attach();
  }

  setSensitivity(s: number): void {
    this.sensitivity = s;
  }

  reset(x: number, z: number, yaw = Math.PI): void {
    this.pos.set(x, 1.62, z);
    this.yaw = yaw;
    this.pitch = 0;
    this.vel.set(0, 0, 0);
    this.moveVec.set(0, 0);
    this.keys.clear();
    this.running = false;
    this.locked = false;
  }

  setTouchMove(x: number, y: number): void {
    this.moveVec.set(THREE.MathUtils.clamp(x, -1, 1), THREE.MathUtils.clamp(y, -1, 1));
  }

  setTouchRun(v: boolean): void {
    this.runTouch = v;
  }

  addLook(dx: number, dy: number): void {
    const s = 0.0022 * this.sensitivity;
    this.yaw -= dx * s;
    this.pitch = THREE.MathUtils.clamp(this.pitch - dy * s, -1.35, 1.35);
  }

  private onKeyDown = (e: KeyboardEvent): void => {
    this.keys.add(e.code);
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
  };

  private onMouseMove = (e: MouseEvent): void => {
    if (document.pointerLockElement && !this.locked) {
      this.addLook(e.movementX, e.movementY);
    }
  };

  private attach(): void {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('mousemove', this.onMouseMove);
  }

  dispose(): void {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('mousemove', this.onMouseMove);
  }

  update(dt: number): void {
    if (this.locked) {
      this.speed = 0;
      this.applyCamera(dt);
      return;
    }

    const f = this.keys.has('KeyW') || this.keys.has('ArrowUp') ? 1 : this.keys.has('KeyS') || this.keys.has('ArrowDown') ? -1 : 0;
    const s = this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? -1 : this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0;
    this.running = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || this.runTouch;

    // vector de entrada (teclado + táctil)
    let ix = s + this.moveVec.x;
    let iz = f - this.moveVec.y;
    const il = Math.hypot(ix, iz);
    if (il > 1) { ix /= il; iz /= il; }

    const sprint = this.running ? 6.2 : 3.7;
    const sin = Math.sin(this.yaw);
    const cos = Math.cos(this.yaw);
    // forward en cámara = -Z rotado por yaw
    const dirX = (ix * cos + iz * sin);
    const dirZ = (iz * cos - ix * sin);

    const accel = 26;
    const tx = dirX * sprint;
    const tz = dirZ * sprint;
    this.vel.x = THREE.MathUtils.lerp(this.vel.x, tx, 1 - Math.exp(-accel * dt * 0.4));
    this.vel.z = THREE.MathUtils.lerp(this.vel.z, tz, 1 - Math.exp(-accel * dt * 0.4));

    const desired = this.pos.clone();
    desired.x += this.vel.x * dt;
    desired.z += this.vel.z * dt;
    const next = collideMove(this.pos, desired, 0.42, this.circles, this.boxes);
    this.pos.set(next.x, this.pos.y, next.z);
    this.speed = Math.hypot(this.vel.x, this.vel.z);

    // pasos
    if (this.speed > 0.7 && this.onStep) {
      this.bobPhase += dt * (this.running ? 12 : 8.4);
      const stride = Math.PI;
      if (this.bobPhase % stride < dt * (this.running ? 12 : 8.4)) {
        this.onStep(this.running, this.indoorFn(this.pos));
      }
    }

    this.applyCamera(dt);
  }

  private applyCamera(dt: number): void {
    const bob = Math.sin(this.bobPhase * 2) * 0.035 * Math.min(1, this.speed / 3.5);
    const sway = Math.cos(this.bobPhase) * 0.02 * Math.min(1, this.speed / 3.5);
    this.camera.position.set(this.pos.x + sway * Math.cos(this.yaw), this.pos.y + bob, this.pos.z + sway * Math.sin(this.yaw));
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;
    // FOV leve al correr
    const targetFov = this.running && this.speed > 4 ? 78 : 72;
    this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, targetFov, dt * 4);
    this.camera.updateProjectionMatrix();
  }

  forward(): THREE.Vector3 {
    return new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, this.yaw, 0));
  }
}
