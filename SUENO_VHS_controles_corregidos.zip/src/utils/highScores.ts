import { HighScoreEntry, SavedRun, Settings } from '../types/game';

const SCORE_KEY = 'suenovhs_scores_v2';
const RUN_KEY = 'suenovhs_run_v2';
const SETTINGS_KEY = 'suenovhs_settings_v2';

const DEFAULT_SCORES: HighScoreEntry[] = [
  { id: 's1', name: 'OP-MÍSTICO', score: 1650, radios: 3, ending: 'BUENO', timeSec: 480, date: '1993-10-31' },
  { id: 's2', name: 'OP-VIGILIA', score: 900, radios: 2, ending: 'CAPTURADO', timeSec: 210, date: '1993-10-31' },
  { id: 's3', name: 'OP-ERRANTE', score: 350, radios: 1, ending: 'MALO', timeSec: 130, date: '1993-10-31' },
];

export function loadScores(): HighScoreEntry[] {
  try {
    const raw = localStorage.getItem(SCORE_KEY);
    if (!raw) return [...DEFAULT_SCORES];
    const parsed = JSON.parse(raw) as HighScoreEntry[];
    if (!Array.isArray(parsed) || parsed.length === 0) return [...DEFAULT_SCORES];
    return parsed.sort((a, b) => b.score - a.score).slice(0, 8);
  } catch {
    return [...DEFAULT_SCORES];
  }
}

export function addScore(entry: Omit<HighScoreEntry, 'id' | 'date'>): { scores: HighScoreEntry[]; rank: number; isRecord: boolean } {
  const prev = loadScores();
  const prevTop = prev[0]?.score ?? 0;
  const full: HighScoreEntry = {
    ...entry,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    date: new Date().toISOString().slice(0, 10),
  };
  const merged = [...prev, full].sort((a, b) => b.score - a.score).slice(0, 8);
  try {
    localStorage.setItem(SCORE_KEY, JSON.stringify(merged));
  } catch { /* ignore */ }
  const rank = merged.findIndex((x) => x.id === full.id) + 1;
  return { scores: merged, rank: rank > 0 ? rank : 99, isRecord: full.score > prevTop && full.score > 0 };
}

export function saveRun(run: SavedRun): void {
  try {
    localStorage.setItem(RUN_KEY, JSON.stringify(run));
  } catch { /* ignore */ }
}

export function loadRun(): SavedRun | null {
  try {
    const raw = localStorage.getItem(RUN_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SavedRun;
    if (parsed && parsed.version === 2 && Array.isArray(parsed.radios)) return parsed;
    return null;
  } catch {
    return null;
  }
}

export function clearRun(): void {
  try {
    localStorage.removeItem(RUN_KEY);
  } catch { /* ignore */ }
}

export function loadSettings(): Settings {
  const def: Settings = { quality: 'medium', volume: 0.8, sensitivity: 1, vhsIntensity: 1, callsign: 'OPERADOR-93' };
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return def;
    return { ...def, ...(JSON.parse(raw) as Partial<Settings>) };
  } catch {
    return def;
  }
}

export function saveSettings(s: Settings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch { /* ignore */ }
}
